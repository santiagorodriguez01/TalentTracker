// ai_integration/services/biometricService.js
import { enrollFace, verifyFace } from "../clients/biometricClient.js";

// ADAPTA este import a tu conexión real (Knex/Sequelize/MySQL pool).
// Si ya tenés un módulo de DB central, úsalo aquí:
import db from "../../core/db/connection.js";

/**
 * Guarda/actualiza el perfil biométrico:
 * - Si el microservicio devuelve embedding_b64 -> se guarda como LONGBLOB
 * - Si no, se guarda la imagen subida como referencia (LONGBLOB) para no violar NOT NULL
 */
export const biometricService = {
  async enrollAlumnoFace(userId, imageFile) {
    const result = await enrollFace(userId, imageFile);
    // Armar LONGBLOB fuente
    let blobBuffer = null;

    if (result && result.embedding_b64) {
      blobBuffer = Buffer.from(result.embedding_b64, "base64");
    } else {
      // fallback: guardar la imagen como referencia (temporal) para no violar NOT NULL
      blobBuffer = imageFile.buffer;
    }

    // UPSERT simple en MySQL (si tu motor no soporta JSON_SET, lo dejamos básico)
    await db.query(
      `
      INSERT INTO biometric_profile (user_id, face_vector, model_version)
      VALUES (?, ?, ?)
      ON DUPLICATE KEY UPDATE
        face_vector = VALUES(face_vector),
        model_version = VALUES(model_version),
        updated_at = CURRENT_TIMESTAMP
      `,
      [userId, blobBuffer, result?.model_version || "mediapipe_v1"]
    );

    // Auditar ENROLL
    await db.query(
      `
      INSERT INTO biometric_audit_log (user_id, action, score, liveness_passed, metadata)
      VALUES (?, 'ENROLL', NULL, FALSE, JSON_OBJECT('message', ?, 'has_embedding', ?))
      `,
      [userId, result?.message || "enrolled", !!result?.embedding_b64]
    );

    return { success: true, user_id: userId, has_embedding: !!result?.embedding_b64 };
  },

  async verifyRevisor(userId, imageFile, challenge = "blink", evidence = {}) {
    const result = await verifyFace(userId, imageFile, challenge, evidence);
    const { allow, score = 0, reason = null } = result || {};

    // Log de verificación
    await db.query(
      `
      INSERT INTO biometric_audit_log (user_id, action, score, liveness_passed, metadata)
      VALUES (?, ?, ?, ?, JSON_OBJECT('reason', ?, 'challenge', ?, 'evidence', CAST(? AS JSON)))
      `,
      [userId, allow ? "ACCESS_GRANTED" : "ACCESS_DENIED", score, allow ? 1 : 0, reason, challenge, JSON.stringify(evidence || {})]
    );

    return { allow: !!allow, score: Number(score || 0), reason };
  },
};
