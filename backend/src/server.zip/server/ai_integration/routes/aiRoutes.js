// ===============================================
// 📁 ai_integration/routes/aiRoutes.js
// ===============================================
import express from "express";
import multer from "multer";
import { authRequired } from "../../middlewares/authRequired.js";
import { asyncHandler } from "../../middlewares/asyncHandler.js";
import * as AIController from "../../../../web/controllers/AIController.js";

const upload = multer({ storage: multer.memoryStorage() });

const router = express.Router();

/**
 * @route POST /ai/alumnos/:id/enroll-face
 * @desc Enrolar rostro de un alumno en el sistema biométrico
 * @access ADMIN, COORDINADOR
 * @body image: archivo de imagen del rostro
 */
router.post(
  "/ai/alumnos/:id/enroll-face",
  authRequired(["ADMIN", "COORDINADOR"]),
  upload.single("image"),
  asyncHandler(AIController.enrollFace)
);

/**
 * @route POST /ai/revisor/:id/verify-face
 * @desc Verificar rostro para acceso biométrico (ej. revisor o staff)
 * @access ADMIN, COORDINADOR, STAFF
 * @body image: archivo de imagen del rostro
 */
router.post(
  "/ai/revisor/:id/verify-face",
  authRequired(["ADMIN", "COORDINADOR", "STAFF"]),
  upload.single("image"),
  asyncHandler(AIController.verifyRevisor)
);

/**
 * @route POST /ai/alumnos/:id/analyze-performance
 * @desc Analizar rendimiento físico del alumno mediante video
 * @access ADMIN, COORDINADOR
 * @body video: archivo de video de entrenamiento
 */
router.post(
  "/ai/alumnos/:id/analyze-performance",
  authRequired(["ADMIN", "COORDINADOR"]),
  upload.single("video"),
  asyncHandler(AIController.analyzePerformance)
);

export default router;
