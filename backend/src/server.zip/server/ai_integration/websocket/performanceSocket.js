// ai_integration/websocket/performanceSocket.js
import WebSocket, { WebSocketServer } from "ws";
import { performanceRealtime } from "./frameProcessor.js";

export function initPerformanceSocket(server) {
  const wss = new WebSocketServer({ server, path: "/ws/performance" });

  wss.on("connection", (ws) => {
    console.log("📡 Nueva conexión WebSocket en /ws/performance");

    ws.on("message", async (data) => {
      try {
        const msg = JSON.parse(data);

        // Estructura esperada:
        // { alumno_id, coordinador_id, frame_b64 }

        if (!msg.frame_b64) return;

        const metrics = await performanceRealtime(msg.frame_b64);

        ws.send(
          JSON.stringify({
            type: "metrics_update",
            alumno_id: msg.alumno_id,
            metrics,
            timestamp: new Date().toISOString(),
          })
        );
      } catch (err) {
        console.error("❌ Error procesando frame:", err.message);
        ws.send(JSON.stringify({ type: "error", message: err.message }));
      }
    });

    ws.on("close", () => console.log("🔌 Cliente desconectado"));
  });

  console.log("✅ WebSocket /ws/performance iniciado");
  return wss;
}
