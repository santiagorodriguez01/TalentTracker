// ai_integration/websocket/frameProcessor.js
import axios from "axios";

const AI_PERFORMANCE_URL = process.env.AI_PERFORMANCE_URL || "http://127.0.0.1:8020/performance";

// Envía un solo frame (convertido desde base64) al microservicio Python
export async function performanceRealtime(frame_b64) {
  try {
    const response = await axios.post(`${AI_PERFORMANCE_URL}/realtime`, { frame_b64 });
    return response.data; // { speed, posture, balance }
  } catch (err) {
    console.error("Error enviando frame al microservicio:", err.message);
    return { error: err.message };
  }
}
